/* Climbo Pisa Logbook – frontend vanilla JS */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const today = () => new Date().toISOString().slice(0, 10);
const fmtDate = d => new Date(d + 'T12:00:00').toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
const cap = s => s[0].toUpperCase() + s.slice(1);
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

const api = async (url, opt = {}) => {
  const r = await fetch('/api' + url, opt);
  const d = r.status === 204 ? {} : await r.json().catch(() => ({}));
  if (r.status === 401 && !url.startsWith('/auth/')) { ME = null; showAuth(); throw new Error(d.error || 'Accedi per continuare'); }
  if (!r.ok) throw new Error(d.error || 'Qualcosa è andato storto');
  return d;
};
const send = (url, body) => api(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
const del = url => api(url, { method: 'DELETE' });

let toastTimer;
const toast = msg => {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (t.hidden = true), 2800);
};
const sheet = (html, wide = false) => {
  const d = $('#dlg');
  d.style.width = wide ? 'min(94vw,560px)' : '';
  d.innerHTML = html;
  if (!d.open) d.showModal();
};
$('#dlg').addEventListener('click', e => { if (e.target.id === 'dlg') e.target.close(); });

const HEX = { start: '#37b24d', mid: '#1c7ed6', top: '#e03131' };
const TOOLS = { start: 'Start', mid: 'Intermedia', top: 'Top' };
const STYLE = { flash: 'Flash', top: 'Top', fail: 'Tentativo' };
const GCOL = { bianco: '#f5f5f7', verde: '#30d158', blu: '#0a84ff', giallo: '#ffd60a', arancione: '#ff9f0a', rosso: '#ff453a', viola: '#bf5af2' };
const TRASH = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>';

let META = { font: [], colors: [], registration: false, sectors: [] };
let ME = null;                                 // utente connesso
let PREV = 'tracer';                           // ultima scheda principale visitata (per il link "indietro")
const TABS = { sessions: 'Sessioni', tracer: 'Traccia', vie: 'Vie create', stats: 'Statistiche', profilo: 'Profilo' };
const T = { wallId: null, tool: 'start', holds: [], mode: 'wall', photo: null, photoUrl: null, wall: null, mapOpen: true, mapSel: null }; // mode: 'wall' = foto parete, 'own' = foto della singola via // stato del tracciatore
let WALLPICK = null;                           // file scelto nel form "carica foto parete"
const COARSE = matchMedia('(pointer:coarse)').matches; // touch: mostra anche il bottone fotocamera

const grade = g => GCOL[g] ? `<span class="grade"><i style="background:${GCOL[g]}"></i>${cap(g)}</span>` : `<span class="grade">${esc(g)}</span>`;
// nelle liste dei gradi: prima i colori della palestra, poi la scala Font.
// gymOnly = solo colori palestra (vie "Climbo Official", che in palestra sono identificate dal colore)
const gradeOpts = (sel = '', gymOnly = false) =>
  `<option value="" disabled ${sel ? '' : 'selected'}>Grado</option>
   <optgroup label="Colori palestra">${META.colors.map(g => `<option value="${g}" ${g === sel ? 'selected' : ''}>${cap(g)}</option>`).join('')}</optgroup>
   ${gymOnly ? '' : `<optgroup label="Scala Font">${META.font.map(g => `<option ${g === sel ? 'selected' : ''}>${g}</option>`).join('')}</optgroup>`}`;
const starsHTML = n => `<span class="stars">${'<span>★</span>'.repeat(n)}<span class="off">${'★'.repeat(5 - n)}</span></span>`;
// badge "Climbo Official" (via già montata in palestra dai setters) + colore delle prese a testo libero
const officialChip = `<span class="chip official" title="Via già montata in palestra dai setters">★ Climbo Official</span>`;
const holdChip = c => `<span class="chip holdc">Prese: ${esc(c)}</span>`;
const attemptOpts = Array.from({ length: 30 }, (_, i) => `<option value="${i + 1}">${plural(i + 1, 'tentativo', 'tentativi')}</option>`).join('');
const head = (title, right = '', sub = '') => `<div class="flex items-end justify-between gap-3 mb-6">
  <div><h1 class="title">${title}</h1>${sub ? `<p class="sub text-[15px] mt-1.5">${sub}</p>` : ''}</div>${right}</div>`;

/* ===================== CARTINA DELLA PALESTRA ===================== */
/* Geometria dei 11 settori (viewBox 900×1080): tratti dritti, tetto a due pannelli.
   I nomi arrivano dal server (META.sectors); lbl = etichetta, cnt = posiz. contatore vie. */
const SECTORS_GEO = {
  1:  { d: 'M45,192 L45,320',                 lbl: { x: 46, y: 352, a: 'start' },          cnt: [74, 256] },
  2:  { d: 'M67,170 L395,170',                lbl: { x: 231, y: 146, a: 'middle' },        cnt: [231, 196] },
  3:  { rect: [397, 187, 200, 146, 16],       lbl: { x: 497, y: 172, a: 'middle' },        cnt: [497, 260] },
  4:  { d: 'M600,170 L773,170',               lbl: { x: 686, y: 146, a: 'middle' },        cnt: [686, 196] },
  5:  { d: 'M795,192 L795,420',               lbl: { x: 869, y: 306, a: 'middle', rot: 90, fs: 9.5 }, cnt: [795, 300] },
  6:  { d: 'M795,442 L680,560',               lbl: { x: 652, y: 508, a: 'end' },           cnt: [737, 501] },
  7:  { d: 'M680,582 L680,680',               lbl: { x: 652, y: 640, a: 'end' },           cnt: [680, 631] },
  8:  { d: 'M680,702 L795,788',               lbl: { x: 652, y: 755, a: 'end' },           cnt: [737, 745] },
  9:  { d: 'M795,810 L795,953',               lbl: { x: 764, y: 890, a: 'end', fs: 9.5 },  cnt: [795, 881] },
  10: { d: 'M773,975 L500,975',               lbl: { x: 640, y: 1014, a: 'middle' },       cnt: [640, 975] },
};
const sectorName = id => { const s = (META.sectors || []).find(x => x.id === id); return s ? `${s.id} · ${s.name}` : '?'; };

function gymMapSVG({ selected = null, hasPhoto = () => true, counts = {}, cls = 'gymmap' } = {}) {
  const wall = s => {
    const g = SECTORS_GEO[s.id], panel = !!g.rect, photo = hasPhoto(s.id), sel = selected === s.id;
    const shape = t => g.rect
      ? `<rect x="${g.rect[0]}" y="${g.rect[1]}" width="${g.rect[2]}" height="${g.rect[3]}" rx="${g.rect[4]}" ${t}/>`
      : `<path d="${g.d}" ${t}/>`;
    const halo = `<g>${shape(`class="gm-halo gm-hp${sel ? ' gm-hsel' : ''}"`)}</g>`;
    const vis = `<g data-vs="${s.id}">${shape(`class="gm-wall${panel ? ' gm-panel' : ''}${photo ? '' : ' gm-ghost'}${sel ? ' gm-on' : ''}"`)}</g>`;
    // il bersaglio del tocco è l'hit (banda larga): su di esso stanno data-sector e il listener;
    // fill come stile inline (batte il CSS .gm-hit { fill:none }) così l'interno dei pannelli è toccabile
    const hit = `<g>${shape(`class="gm-hit gm-hp" data-sector="${s.id}" data-photo="${photo ? 1 : 0}" style="${panel ? 'fill:transparent' : 'fill:none'}"`)}</g>`;
    const l = g.lbl;
    const lbl = `<text class="gm-lbl" x="${l.x}" y="${l.y}" text-anchor="${l.a}"${l.rot ? ` transform="rotate(${l.rot} ${l.x} ${l.y})"` : ''}${l.fs ? ` style="font-size:${l.fs}px"` : ''}>${s.id} · ${esc(s.name).toUpperCase()}</text>`;
    const c = counts[s.id];
    const cnt = c ? `<g class="gm-cnt" transform="translate(${g.cnt[0]},${g.cnt[1]})"><circle r="10"/><text y="4" text-anchor="middle">${c}</text></g>` : '';
    return halo + vis + hit + lbl + cnt;
  };
  return `<svg class="${cls}" viewBox="0 0 900 1080" role="img" aria-label="Cartina della palestra, pareti toccabili">${(META.sectors || []).map(wall).join('')}</svg>`;
}
const bindMap = (root, onTap) => {
  if (!root) return;
  root.querySelectorAll('.gm-hit').forEach(el =>
    el.addEventListener('click', () => onTap(+el.dataset.sector, el.dataset.photo === '1')));
};
// accende subito il settore toccato (feedback istantaneo anche sui settori con foto)
const lightSector = (root, id) => {
  const g = root?.querySelector(`[data-vs="${id}"] .gm-wall`);
  if (g) g.classList.add('gm-on');
};

/* Icone per stati vuoti e KPI */
const ICONS = {
  board: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v4M16 2v4M3 9h18M5 4h14a2 2 0 012 2v13a2 2 0 01-2 2H5a2 2 0 01-2-2V6a2 2 0 012-2z"/></svg>',
  rock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 20l6-11 4 7 3-4 5 8z"/><circle cx="10" cy="6.5" r="1.6"/></svg>',
  chart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M5 20V10M12 20V4M19 20v-7"/></svg>',
  bolt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L4 14h6l-1 8 9-12h-6z"/></svg>',
  flag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V4a1 1 0 011-1h9l-1.5 4L20 7v9h-9l-1-3H5"/></svg>',
  trophy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0zM7 5H4a3 3 0 003 4M17 5h3a3 3 0 01-3 4"/></svg>',
};
const empty = (icon, title, text, cta = '') => `
  <div class="card empty col-span-full">
    <div class="ico">${ICONS[icon]}</div>
    <h3>${title}</h3>
    <p class="sub text-sm max-w-[36ch]">${text}</p>
    ${cta}
  </div>`;

/* Marker posizionati in % → restano sulle prese giuste a qualsiasi dimensione schermo */
const markers = holds => holds.map((h, i) =>
  `<span class="marker" data-i="${i}" style="left:${h.x}%;top:${h.y}%;border-color:${HEX[h.type]};background:${HEX[h.type]}55"></span>`).join('');

/* pickSession: invece del link al dettaglio, il tocco sulla card aggiunge la via a quella sessione */
const boulderCard = (b, withWall = false, pickSession = null) => `
  <${pickSession ? `button type="button" data-pick="${b.id}"` : `a href="#boulder/${b.id}"`} class="card overflow-hidden block${pickSession ? ' w-full text-left' : ''}" style="text-decoration:none;color:inherit;${pickSession ? 'font:inherit;cursor:pointer' : ''}">
    <div class="thumb relative"><img src="${esc(b.image_url)}" alt="" class="block w-full h-auto"><div class="absolute inset-0">${markers(b.holds)}</div></div>
    <div class="p-3"><div class="flex items-center gap-2">${grade(b.grade)}<span class="flex-1 truncate text-sm font-medium">${esc(b.name)}</span></div>
      <div class="flex items-center gap-2 mt-2 flex-wrap"><span class="chip ${b.best || 'fail'}">${b.best ? STYLE[b.best] : 'Da fare'}</span>
        ${b.official ? officialChip : ''}${b.hold_color ? holdChip(b.hold_color) : ''}
        ${Number(b.rating) ? `<span class="sub text-xs" style="color:var(--orange)">★ ${b.rating}</span>` : ''}
        ${withWall ? `<span class="sub text-xs truncate">${esc(b.wall_name)}${b.attached === false ? ' · foto precedente' : ''}${b.mine ? '' : ' · ' + esc(b.author)}</span>` : ''}</div></div></${pickSession ? 'button' : 'a'}>`;

/* ===================== SESSIONI ===================== */
async function viewSessions() {
  const sessions = await api('/sessions');

  const row = l => `
    <li class="sep flex items-center gap-3 py-3">
      ${grade(l.grade)}
      <div class="flex-1 min-w-0">
        <div class="truncate font-medium">${l.boulder_id
          ? `<a class="link" href="#boulder/${l.boulder_id}">${esc(l.name)} ›</a>`
          : (esc(l.name) || '<span class="sub">Blocco libero</span>')}</div>
        <div class="flex items-center gap-2 mt-1"><span class="chip ${l.style}">${STYLE[l.style]}</span>
          <span class="sub text-xs">${plural(l.attempts, 'tentativo', 'tentativi')}</span></div>
      </div>
      <button class="icon" data-del-log="${l.id}" aria-label="Elimina blocco">${TRASH}</button>
    </li>`;

  const card = s => `
  <article class="card p-5">
    <div class="flex items-start justify-between gap-3">
      <div><h2 class="text-xl font-bold capitalize" style="letter-spacing:-.025em">${fmtDate(s.date)}</h2>
        <p class="sub text-sm mt-0.5">${esc(s.gym)}${s.notes ? ' · ' + esc(s.notes) : ''}</p></div>
      <div class="flex items-center gap-1.5 shrink-0">
        <span class="chip fail">${plural(s.logs.length, 'blocco', 'blocchi')}</span>
        <button class="icon" data-del-session="${s.id}" aria-label="Elimina sessione">${TRASH}</button>
      </div>
    </div>
    <ul class="mt-3">${s.logs.map(row).join('') || '<li class="sep py-3 sub text-sm">Nessun blocco registrato.</li>'}</ul>
    <div class="sep pt-3 mt-3 flex gap-2">
      <button class="btn sec sm flex-1" data-freeblock="${s.id}">＋ Blocco libero</button>
      <button class="btn sec sm flex-1" data-pickboulder="${s.id}">Dalle vie create…</button>
    </div>
  </article>`;

  $('#app').innerHTML = head('Sessioni', '<button class="btn sm whitespace-nowrap" data-new-session>Nuova sessione</button>',
    'Il diario delle tue giornate in palestra.') +
    `<div class="grid gap-4">${sessions.map(card).join('') ||
      empty('board', 'Nessuna sessione', 'Crea la prima sessione e registra i blocchi che chiudi in palestra.',
        '<button class="btn sm" data-new-session>Crea la prima sessione</button>')}</div>`;
}

const newSessionSheet = (afterBoulderId = null) => sheet(`
  <form data-session ${afterBoulderId ? `data-after-bid="${afterBoulderId}"` : ''} class="grid gap-3">
    <h2 class="text-xl font-bold">Nuova sessione</h2>
    <input name="date" type="date" value="${today()}" required class="field" aria-label="Data">
    <input name="gym" value="Climbo Pisa" placeholder="Palestra / settore" class="field" aria-label="Palestra">
    <input name="notes" placeholder="Note" class="field" aria-label="Note">
    <div class="flex gap-2 mt-1"><button type="button" class="btn sec flex-1" data-close>Annulla</button><button class="btn flex-1">Crea</button></div>
  </form>`);

/* Blocco senza prese tracciate: solo nome, grado e risultato */
const freeBlockSheet = sessionId => sheet(`
  <form data-freeblock="${sessionId}" class="grid gap-3">
    <h2 class="text-xl font-bold">Blocco libero</h2>
    <input name="name" class="field" placeholder="Nome della via (facoltativo)" maxlength="80" aria-label="Nome della via">
    <select name="grade" class="field" aria-label="Grado">${gradeOpts()}</select>
    <div class="grid grid-cols-2 gap-2">
      <select name="style" class="field" aria-label="Stile"><option value="flash">Flash</option><option value="top" selected>Top</option><option value="fail">Tentativo</option></select>
      <select name="attempts" class="field" aria-label="Numero di tentativi">${attemptOpts}</select>
    </div>
    <div class="flex gap-2 mt-1"><button type="button" class="btn sec flex-1" data-close>Annulla</button><button class="btn flex-1">Aggiungi</button></div>
  </form>`);

/* ===================== SCEGLI DALLE VIE CREATE (pagina piena, filtri come «Vie create») ===================== */
const PICKV = { sessionId: null, q: '', sector: '', grade: '', status: 'all', origin: 'all' }; // stato di #pick/:sessionId

async function viewPick(sessionId) {
  PICKV.sessionId = Number(sessionId) || null;
  if (!PICKV.sessionId) { location.hash = '#sessions'; return; }
  const [sessions, all] = await Promise.all([api('/sessions'), api('/boulders')]);
  const s = sessions.find(x => x.id === PICKV.sessionId);
  if (!s) { location.hash = '#sessions'; return; }
  PICKV.all = all.filter(b => b.attached); // nel log si registrano le vie attuali; le archiviate restano in «Vie create»
  const sel = (v, cur) => (v === cur ? 'selected' : '');
  $('#app').innerHTML = `<a href="#sessions" class="link inline-block mb-3">‹ Sessioni</a>` +
    head('Aggiungi alla sessione', '<span id="pickCount" class="sub pb-1"></span>',
      `Sessione del <span class="capitalize font-semibold">${fmtDate(s.date)}</span> · ${esc(s.gym)}: tocca la foto della via da registrare.`) + `
  <div class="grid gap-3 mb-5">
    <div class="seg" role="group" aria-label="Origine della via">
      ${[['all', 'Tutte'], ['users', 'Utenti'], ['official', 'Climbo Official']].map(([k, l]) =>
        `<button data-porigin="${k}" class="${PICKV.origin === k ? 'on' : ''}">${l}</button>`).join('')}
    </div>
    <p class="sub text-xs px-1 -mt-1">«Climbo Official» sono le vie già montate in palestra dai setters; «Utenti» quelle proposte dagli altri climbatori.</p>
    <input id="pvq" type="search" class="field" placeholder="Cerca una via" value="${esc(PICKV.q)}" aria-label="Cerca una via">
    <div class="grid grid-cols-2 gap-2">
      <button id="pvmapBtn" class="field text-left flex items-center justify-between gap-2" data-pvmap aria-label="Filtro settore con cartina">
        <span class="truncate">${PICKV.sector ? sectorName(+PICKV.sector) : 'Tutti i settori'}</span><span class="sub" aria-hidden="true">🗺️</span>
      </button>
      <select id="pvgrade" class="field" aria-label="Grado"><option value="">Tutti i gradi</option>
        <optgroup label="Colori palestra">${META.colors.map(g => `<option value="${g}" ${sel(g, PICKV.grade)}>${cap(g)}</option>`).join('')}</optgroup>
        <optgroup label="Scala Font">${META.font.map(g => `<option ${sel(g, PICKV.grade)}>${g}</option>`).join('')}</optgroup></select>
    </div>
    <div class="seg" role="group" aria-label="Stato">
      ${[['all', 'Ogni stato'], ['todo', 'Da fare'], ['done', 'Chiuse']].map(([k, l]) => `<button data-pstatus="${k}" class="${PICKV.status === k ? 'on' : ''}">${l}</button>`).join('')}
    </div>
  </div>
  <div id="pickList" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3"></div>`;
  renderPick();
}

function renderPick() {
  const q = PICKV.q.trim().toLowerCase();
  const list = PICKV.all.filter(b =>
    (PICKV.origin === 'all' || (PICKV.origin === 'official' ? !!b.official : !b.official)) &&
    (!q || b.name.toLowerCase().includes(q)) &&
    (!PICKV.sector || String(b.sector) === PICKV.sector) &&
    (!PICKV.grade || b.grade === PICKV.grade) &&
    (PICKV.status === 'all' || (PICKV.status === 'done' ? ['flash', 'top'].includes(b.best) : !['flash', 'top'].includes(b.best))));
  $('#pickCount').textContent = plural(list.length, 'via', 'vie');
  $('#pickList').innerHTML = list.map(b => boulderCard(b, true, PICKV.sessionId)).join('') ||
    empty('rock', 'Nessuna via con questi filtri', 'Prova a togliere qualche filtro. Le vie archiviate (foto di settore sostituita) si vedono solo in «Vie create».',
      '<button class="btn sm" data-preset>Azzera filtri</button>');
}

/* Aggiunge una via (tua o di altri) a una sessione: grado precompilato dal blocco */
async function logBoulderSheet(sessionId, boulderId) {
  const b = await api('/boulders/' + boulderId);
  sheet(`
    <form data-logboulder="${sessionId}" data-bid="${b.id}" class="grid gap-3">
      <h2 class="text-xl font-bold">Aggiungi «${esc(b.name)}»</h2>
      <div class="card p-3 flex items-center gap-3" style="box-shadow:none;background:var(--fill)">
        <img src="${esc(b.image_url)}" class="h-14 w-14 rounded-xl object-cover flex-none" alt="">
        <div class="flex-1 min-w-0"><div class="font-semibold text-sm truncate">${esc(b.name)}</div>
          <div class="sub text-xs truncate">${esc(b.wall_name)}${b.mine ? '' : ' · di ' + esc(b.author)}</div></div>
        ${grade(b.grade)}
      </div>
      <select name="grade" class="field" aria-label="Grado">${gradeOpts(b.grade)}</select>
      <div class="grid grid-cols-2 gap-2">
        <select name="style" class="field" aria-label="Stile"><option value="flash">Flash</option><option value="top" selected>Top</option><option value="fail">Tentativo</option></select>
        <select name="attempts" class="field" aria-label="Numero di tentativi">${attemptOpts}</select>
      </div>
      <div class="flex gap-2 mt-1"><button type="button" class="btn sec flex-1" data-close>Annulla</button><button class="btn flex-1">Aggiungi alla sessione</button></div>
    </form>`);
}

/* Da una via: sceglie la sessione dove registrarla (o ne crea una nuova al volo) */
async function addSessionSheet(boulderId) {
  const sessions = await api('/sessions');
  sheet(`
    <h2 class="text-xl font-bold">Aggiungi alla sessione</h2>
    <p class="sub text-sm mt-0.5 mb-3">Scegli in quale giornata registrare la salite.</p>
    <div class="grid gap-2 max-h-[38vh] overflow-y-auto">
      ${sessions.map(s => `<button class="card p-3 text-left flex items-center justify-between gap-2 w-full" style="box-shadow:none;background:var(--fill)" data-session-pick="${s.id}" data-bid="${boulderId}">
          <div class="min-w-0"><div class="font-medium capitalize text-sm truncate">${fmtDate(s.date)}</div>
            <div class="sub text-xs">${plural(s.logs.length, 'blocco', 'blocchi')} · ${esc(s.gym)}</div></div>
          <span class="sub">›</span>
        </button>`).join('') || '<p class="sub text-sm">Non hai ancora nessuna sessione.</p>'}
    </div>
    <button class="btn sec w-full mt-2" data-new-session data-after-bid="${boulderId}">＋ Nuova sessione…</button>`);
}

/* ===================== TRACCIA BLOCCO ===================== */
async function viewTracer() {
  const [walls, boulders] = await Promise.all([api('/walls'), api('/boulders')]);
  if (!walls.find(w => w.id === T.wallId)) { // default: la prima parete con foto
    T.wallId = walls[0]?.id ?? null;
    T.holds = [];
  }
  const wall = walls.find(w => w.id === T.wallId) || null;
  const sectorWalls = new Map(walls.filter(w => w.sector).map(w => [w.sector, w]));
  const mine = wall ? boulders.filter(b => b.wall_id === wall.id) : []; // vie attuali su questa foto parete
  const counts = {};
  boulders.forEach(b => { if (b.sector) counts[b.sector] = (counts[b.sector] || 0) + 1; });
  const mapOpen = !wall || T.mapOpen;
  if (!mapOpen) T.mapSel = wall?.sector ?? null;

  const mapCard = `
  <div class="card p-4 mb-4">
    <div class="flex items-center justify-between gap-2">
      <h2 class="text-lg font-bold" style="letter-spacing:-.02em">Dove si trova la parete?</h2>
      ${wall ? '<button class="btn sec sm" data-map-toggle>Chiudi cartina</button>' : ''}
    </div>
    <p class="sub text-sm mt-0.5 mb-2">Tocca il tratto della cartina${ME.admin ? ': se il settore ha già la foto si traccia lì, se no la carichi al volo.' : ': si illumina di arancione; se il settore ha già la foto si traccia lì.'}</p>
    <div class="rounded-2xl overflow-hidden" style="border:1px solid var(--sep)">${gymMapSVG({ selected: T.mapSel, hasPhoto: id => sectorWalls.has(id), counts })}</div>
  </div>`;

  const wallBar = wall ? `
  <div class="card p-4 mb-4 flex items-center gap-3 flex-wrap">
    <span class="chip fail" style="font-size:13px">${sectorName(wall.sector)}</span>
    <span class="font-bold">${esc(wall.name)}</span>
    <span class="flex-1"></span>
    <button class="btn sec sm" data-map-toggle>Cambia parete</button>
    ${ME.admin ? `<button class="btn sec sm" data-rewall="${wall.sector}">Nuova foto</button>
      <button class="icon" data-del-wall="${wall.id}" data-n-boulders="${mine.length}" aria-label="Elimina foto del settore">${TRASH}</button>` : ''}
  </div>` : '';

  $('#app').innerHTML = head('Traccia', '', 'Scegli la parete sulla cartina, poi posiziona start, intermedie e top sulla foto.') + `
  ${mapOpen ? mapCard : wallBar}
  <div class="grid lg:grid-cols-[1fr_330px] gap-5">
    <section class="grid gap-3 content-start">
      <div class="seg" role="group" aria-label="Foto da usare">
        <button data-mode="wall" class="${T.mode === 'wall' ? 'on' : ''}">Parete intera</button>
        <button data-mode="own" class="${T.mode === 'own' ? 'on' : ''}">Foto della via</button>
      </div>
      <div class="seg" role="group" aria-label="Tipo di presa">
        ${Object.entries(TOOLS).map(([k, l]) => `<button data-tool="${k}" class="${T.tool === k ? 'on' : ''}"><i style="background:${HEX[k]}"></i>${l}</button>`).join('')}
      </div>
      <div id="stageWrap"></div>
      <p class="sub text-sm px-1">Tocca la foto per posizionare la presa. Tocca un cerchio per rimuoverlo. <span id="count"></span></p>
    </section>
    <aside class="card p-5 grid gap-3 content-start self-start">
      <input id="bName" class="field" placeholder="Nome del blocco" maxlength="80" aria-label="Nome blocco">
      <select id="bGrade" class="field" aria-label="Grado stimato">${gradeOpts()}</select>
      <label class="flex items-start gap-2.5 text-sm font-medium" style="cursor:pointer">
        <input id="bOfficial" type="checkbox" class="mt-1" style="accent-color:var(--orange);width:16px;height:16px;flex:none">
        <span class="leading-snug" style="color:var(--orange)">★ Climbo Official
          <span class="sub block text-xs font-normal mt-0.5" style="color:var(--sub)">Via già montata in palestra dai setters, che vuoi aggiungere al tuo logbook.</span>
        </span>
      </label>
      <input id="bHoldColor" class="field" placeholder="Colore delle prese (es. nere, gialle fluo…)" maxlength="40" hidden aria-label="Colore delle prese">
      <div class="flex gap-2"><button id="undo" class="btn sec sm flex-1">Annulla ultima</button><button id="clear" class="btn sec sm flex-1">Svuota</button></div>
      <button id="save" class="btn">Salva blocco</button>
    </aside>
  </div>
  <h2 class="text-2xl font-bold mt-10 mb-4" style="letter-spacing:-.025em">Vie su ${wall ? esc(wall.name) : 'questa parete'} <span class="sub font-medium text-lg">${mine.length}</span></h2>
  <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
    ${mine.map(b => boulderCard(b)).join('')
      || '<p class="sub col-span-full">Nessuna via su questa parete. Posiziona le prese qui sopra e salva il blocco.</p>'}
  </div>`;
  T.wall = wall;
  if (mapOpen) bindMap($('#app'), async (id, hasPhoto) => {
    T.mapSel = id; // il settore toccato si illumina sempre di arancione
    if (hasPhoto) {
      if (T._nav) return; // evita doppi tap durante il cambio
      T._nav = true;
      lightSector($('#app'), id); // accensione immediata...
      setTimeout(() => { // ...poi passaggio alla parete scelta
        T._nav = false;
        T.wallId = sectorWalls.get(id).id; T.mapOpen = false;
        if (T.mode !== 'own') T.holds = [];
        viewTracer();
      }, 380);
      return;
    }
    await viewTracer(); // ridisegna subito con il settore selezionato
    if (ME.admin) return newWallSheet(id); // solo l'admin carica le foto dei settori
    toast('Le foto dei settori le carica solo l’admin');
  });
  drawStage();
}

/* Bottoni per scegliere la foto: su telefono sia fotocamera sia galleria, su desktop la galleria */
const pickPhoto = (cls, label = 'Scegli foto') => COARSE
  ? `<div class="grid grid-cols-2 gap-2">
      <label class="btn sec sm text-center cursor-pointer">📷 Fotocamera<input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" class="hidden ${cls}"></label>
      <label class="btn sec sm text-center cursor-pointer">🖼️ Galleria<input type="file" accept="image/jpeg,image/png,image/webp" class="hidden ${cls}"></label>
    </div>`
  : `<label class="btn sec sm text-center cursor-pointer inline-block">🖼️ ${label}<input type="file" accept="image/jpeg,image/png,image/webp" class="hidden ${cls}"></label>`;

/* Mostra la foto della parete oppure quella dedicata alla singola via (più vicina = prese più grandi) */
function drawStage() {
  const own = T.mode === 'own', src = own ? T.photoUrl : T.wall?.image_url;
  $('#stageWrap').innerHTML = src
    ? `<div id="stage" class="relative rounded-3xl overflow-hidden" style="background:var(--card)">
         <img src="${esc(src)}" alt="" class="block w-full h-auto pointer-events-none" draggable="false"><div id="mk"></div></div>
       ${own ? pickPhoto('ownPhoto', 'Cambia foto') : ''}`
    : own
      ? `<div class="card empty cursor-pointer">
           <div class="ico">${ICONS.rock}</div>
           <h3>Scegli la foto della via</h3>
           <span class="sub text-sm max-w-[36ch]">Inquadra solo questo blocco: le prese risultano più grandi e facili da segnare.</span>
           ${pickPhoto('ownPhoto')}
         </div>`
      : `<div class="card empty col-span-full">
           <div class="ico">${ICONS.rock}</div>
           <h3>Nessuna parete selezionata</h3>
           <span class="sub text-sm max-w-[36ch]">Scegli un settore sulla cartina e carica la sua foto per iniziare a tracciare.</span>
         </div>`;
  drawMarkers();
}

/* Riduce le foto del telefono (max 2000 px) per un upload più rapido; le percentuali dei marker restano valide */
async function shrink(file, max = 2000) {
  try {
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.85));
    return blob ? new File([blob], 'via.jpg', { type: 'image/jpeg' }) : file;
  } catch { return file; }
}
const clearPhoto = () => { if (T.photoUrl) URL.revokeObjectURL(T.photoUrl); T.photo = T.photoUrl = null; };

function drawMarkers() {
  const mk = $('#mk'); if (!mk) return;
  mk.innerHTML = markers(T.holds);
  const c = k => T.holds.filter(h => h.type === k).length;
  $('#count').textContent = `${c('start')} start · ${c('mid')} intermedie · ${c('top')} top`;
}

/* Il click viene convertito in % rispetto al riquadro della foto: coordinate indipendenti dalla dimensione dello schermo */
function handleStageClick(e) {
  const stage = e.target.closest('#stage');
  const m = e.target.closest('.marker');
  if (m) { T.holds.splice(+m.dataset.i, 1); return drawMarkers(); }
  const r = stage.getBoundingClientRect();
  const x = ((e.clientX - r.left) / r.width) * 100;
  const y = ((e.clientY - r.top) / r.height) * 100;
  if (x < 0 || x > 100 || y < 0 || y > 100) return;
  T.holds.push({ type: T.tool, x: +x.toFixed(2), y: +y.toFixed(2) });
  drawMarkers();
}

async function saveBoulder() {
  const official = $('#bOfficial')?.checked;
  const name = $('#bName').value.trim(), g = $('#bGrade').value;
  if (!official && !name) return toast('Dai un nome al blocco');
  if (!g) return toast('Scegli il grado');
  if (!T.holds.some(h => h.type === 'start') || !T.holds.some(h => h.type === 'top')) return toast('Servono almeno una presa Start e una Top');
  if (T.mode === 'own' && !T.photo) return toast('Scegli la foto della via');
  const fd = new FormData();
  fd.append('wall_id', T.wallId); fd.append('name', name); fd.append('grade', g); fd.append('holds', JSON.stringify(T.holds));
  if (official) {
    fd.append('official', 'true');
    fd.append('hold_color', $('#bHoldColor').value.trim());
  }
  if (T.mode === 'own') fd.append('image', T.photo);
  await api('/boulders', { method: 'POST', body: fd });
  T.holds = []; clearPhoto(); toast('Blocco salvato'); viewTracer();
}

/* Carica foto di un settore della cartina (nome fisso) o di una parete libera */
/* Carica o sostituisce la foto di un settore della cartina (solo admin) */
const newWallSheet = (sectorId = null) => {
  if (!ME.admin) return toast('Le foto dei settori le carica solo l’admin');
  if (!sectorId || !SECTORS_GEO[sectorId]) return;
  WALLPICK = { sector: sectorId, file: null, url: null };
  const s = (META.sectors || []).find(x => x.id === sectorId);
  sheet(`
    <h2 class="text-xl font-bold">${s ? `Foto di ${s.id} · ${esc(s.name)}` : 'Carica una foto'}</h2>
    <p class="sub text-sm mt-0.5 mb-3">Se sostituisci una foto esistente tutte le vie tracciate vengono archiviate:
      spariscono dalla parete e restano solo in «Vie create» con il filtro «Tutte».</p>
    ${pickPhoto('wallPhoto')}
    <div id="wallPrev" class="grid place-items-center mt-3" hidden></div>
    <div class="flex gap-2 mt-3"><button type="button" class="btn sec flex-1" data-close>Annulla</button><button id="wallSave" class="btn flex-1" disabled>Carica</button></div>
  `);
};

/* ===================== VIE CREATE ===================== */
const VIE = { q: '', sector: '', grade: '', status: 'all', scope: 'attuali', origin: 'all' }; // scope: attuali = parete con foto valida; origin: all/users/official
let ALLVIE = [];
async function viewVie() {
  ALLVIE = await api('/boulders'); // vie di tutta la palestra, tue e degli altri, attuali e archiviate
  if (VIE.sector && !META.sectors.some(s => String(s.id) === VIE.sector)) VIE.sector = '';
  const sel = (v, cur) => (v === cur ? 'selected' : '');
  $('#app').innerHTML = head('Vie create', '<span id="vieCount" class="sub pb-1"></span>',
    'Tutti i blocchi tracciati in palestra, da te e dagli altri, anche quelli ancora da chiudere.') + `
  <div class="grid gap-3 mb-5">
    <div class="seg" role="group" aria-label="Quale vie mostrare">
      ${[['attuali', 'Attuali'], ['all', 'Tutte le vie mai create']].map(([k, l]) => `<button data-vscope="${k}" class="${VIE.scope === k ? 'on' : ''}">${l}</button>`).join('')}
    </div>
    <p class="sub text-xs px-1 -mt-1">«Attuali» mostra solo le vie sulle foto di settore valide; sostituendo una foto le vecchie vie restano elencate qui scegliendo «Tutte».</p>
    <div class="seg" role="group" aria-label="Origine della via">
      ${[['all', 'Tutte'], ['users', 'Utenti'], ['official', 'Climbo Official']].map(([k, l]) =>
        `<button data-vorigin="${k}" class="${VIE.origin === k ? 'on' : ''}">${l}</button>`).join('')}
    </div>
    <p class="sub text-xs px-1 -mt-1">«Climbo Official» sono le vie già montate in palestra dai setters; «Utenti» quelle proposte dagli altri climbatori.</p>
    <input id="vq" type="search" class="field" placeholder="Cerca una via" value="${esc(VIE.q)}" aria-label="Cerca una via">
    <div class="grid grid-cols-2 gap-2">
      <button id="vmapBtn" class="field text-left flex items-center justify-between gap-2" data-mapfilter aria-label="Filtro settore con cartina">
        <span class="truncate">${VIE.sector ? sectorName(+VIE.sector) : 'Tutti i settori'}</span><span class="sub" aria-hidden="true">🗺️</span>
      </button>
      <select id="vgrade" class="field" aria-label="Grado"><option value="">Tutti i gradi</option>
        <optgroup label="Colori palestra">${META.colors.map(g => `<option value="${g}" ${sel(g, VIE.grade)}>${cap(g)}</option>`).join('')}</optgroup>
        <optgroup label="Scala Font">${META.font.map(g => `<option ${sel(g, VIE.grade)}>${g}</option>`).join('')}</optgroup></select>
    </div>
    <div class="seg" role="group" aria-label="Stato">
      ${[['all', 'Ogni stato'], ['todo', 'Da fare'], ['done', 'Chiuse']].map(([k, l]) => `<button data-vstatus="${k}" class="${VIE.status === k ? 'on' : ''}">${l}</button>`).join('')}
    </div>
  </div>
  <div id="vieList" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3"></div>`;
  renderVie();
}

// filtro settori con la cartina della palestra (invece dell'elenco); usato da «Vie create» (VIE) e da #pick (PICKV)
const mapFilterSheet = (state = VIE, render = renderVie, btnId = 'vmapBtn', clearAttr = 'vclear', counts = null) => {
  counts = counts || (() => { const c = {}; ALLVIE.forEach(b => { if (b.sector) c[b.sector] = (c[b.sector] || 0) + 1; }); return c; })();
  sheet(`
    <h2 class="text-xl font-bold">Filtra per settore</h2>
    <p class="sub text-sm mt-0.5 mb-3">Tocca il tratto della cartina: il numero indica quante vie ci sono. Tocca il settore già selezionato per togliere il filtro.</p>
    <div id="vfmap" class="rounded-2xl overflow-hidden" style="border:1px solid var(--sep)">${gymMapSVG({ selected: state.sector === '' ? null : +state.sector, counts })}</div>
    ${state.sector ? `<button class="btn sec mt-3 w-full" data-${clearAttr}>Tutti i settori</button>` : ''}`);
  bindMap($('#vfmap'), id => {
    state.sector = state.sector === String(id) ? '' : String(id);
    $('#dlg').close();
    const btn = $('#' + btnId + ' span'); if (btn) btn.textContent = state.sector ? sectorName(+state.sector) : 'Tutti i settori';
    render();
  });
};

function renderVie() {
  const q = VIE.q.trim().toLowerCase();
  const list = ALLVIE.filter(b =>
    (VIE.scope === 'attuali' ? b.attached : true) &&
    (VIE.origin === 'all' || (VIE.origin === 'official' ? !!b.official : !b.official)) &&
    (!q || b.name.toLowerCase().includes(q)) &&
    (!VIE.sector || String(b.sector) === VIE.sector) &&
    (!VIE.grade || b.grade === VIE.grade) &&
    (VIE.status === 'all' || (VIE.status === 'done' ? ['flash', 'top'].includes(b.best) : !['flash', 'top'].includes(b.best))));
  $('#vieCount').textContent = plural(list.length, 'via', 'vie');
  $('#vieList').innerHTML = list.map(b => boulderCard(b, true)).join('') ||
    (ALLVIE.length
      ? empty('rock', 'Nessuna via con questi filtri', 'Prova a togliere qualche filtro di ricerca, o passa a «Tutte le vie mai create».', '<button class="btn sm" data-reset-filters>Azzera filtri</button>')
      : empty('rock', 'Nessuna via tracciata', 'Posiziona le prese su una parete e salva il tuo primo blocco.',
        '<a class="btn sm" href="#tracer" style="text-decoration:none">Traccia la prima via</a>'));
}

/* ===================== DETTAGLIO BLOCCO ===================== */
let REV = null; // stato del form recensione: { bid, stars }
async function viewBoulder(id) {
  const b = await api('/boulders/' + id);
  const mine = (b.reviews || []).find(r => r.user_id === ME.id);
  REV = { bid: b.id, stars: mine?.stars || 0 };
  const avg = b.reviews?.length ? b.reviews.reduce((a, r) => a + r.stars, 0) / b.reviews.length : null;
  const revRow = r => `<li class="sep py-3">
    <div class="flex items-center gap-3">${starsHTML(r.stars)}
      <span class="text-sm font-semibold flex-1 truncate">${esc(r.user_name)}</span>
      <span class="sub text-xs">${fmtDate(r.date)}</span>
      ${r.user_id === ME.id ? `<button class="icon" data-del-review="${r.id}" aria-label="Elimina la tua recensione">${TRASH}</button>` : ''}
    </div>
    ${r.comment ? `<p class="text-sm mt-1.5" style="white-space:pre-wrap">${esc(r.comment)}</p>` : ''}
  </li>`;

  $('#app').innerHTML = `
  <a href="#${PREV}" class="link inline-block mb-3">‹ ${TABS[PREV]}</a>
  <div class="grid lg:grid-cols-[1fr_330px] gap-5">
    <div class="view relative rounded-3xl overflow-hidden" style="background:var(--card)">
      <img src="${esc(b.image_url)}" alt="${esc(b.name)}" class="block w-full h-auto"><div class="absolute inset-0">${markers(b.holds)}</div>
    </div>
    <div class="grid gap-4 content-start">
      <div class="card p-5">
        <h1 class="title" style="font-size:28px">${esc(b.name)}</h1>
        <div class="flex items-center gap-3 mt-3">${grade(b.grade)}<span class="sub text-sm">${b.sector ? sectorName(b.sector) : esc(b.wall_name)}</span></div>
        ${b.official ? `<div class="flex items-center gap-2 mt-3 flex-wrap">${officialChip}${b.hold_color ? holdChip(b.hold_color) : ''}</div>` : ''}
        <p class="sub text-sm mt-2">${b.mine ? 'Tracciata da te' : `Tracciata da <b>${esc(b.author)}</b>`}${b.n_logs ? ` · ${plural(b.n_logs, 'salita', 'salite')} in palestra` : ''}</p>
        ${avg ? `<div class="flex items-center gap-2 mt-3">${starsHTML(Math.round(avg))}<span class="text-sm font-semibold">${avg.toFixed(1)}</span><span class="sub text-xs">· ${plural(b.reviews.length, 'recensione', 'recensioni')}</span></div>` : ''}
        <div class="seg mt-4" style="pointer-events:none;font-size:12.5px">${Object.entries(TOOLS).map(([k, l]) =>
          `<button style="white-space:nowrap"><i style="background:${HEX[k]}"></i>${l}&nbsp;<b>${b.holds.filter(h => h.type === k).length}</b></button>`).join('')}</div>
        <button class="btn mt-4 w-full" data-add-session="${b.id}">Aggiungi alla sessione</button>
      </div>
      <div class="card p-5">
        <h2 class="font-bold mb-1">Salite registrate</h2>
        <ul>${b.logs.map(l => `<li class="sep py-3 flex items-center gap-3">
          <div class="flex-1 min-w-0"><div class="text-sm capitalize truncate">${fmtDate(l.date)}</div>
            <div class="sub text-xs">${esc(l.user_name)} · ${esc(l.gym)}</div></div>
          <span class="chip ${l.style}">${STYLE[l.style]}</span><span class="sub text-xs">${plural(l.attempts, 'tentativo', 'tentativi')}</span></li>`).join('')
          || '<li class="sep py-3 sub text-sm">Nessuno l’ha ancora registrata in una sessione.</li>'}</ul>
      </div>
      ${b.mine ? '<button class="btn sec" style="color:var(--red)" data-del-boulder="' + b.id + '">Elimina blocco</button>' : ''}
    </div>
  </div>
  <h2 class="text-2xl font-bold mt-10" style="letter-spacing:-.025em">Recensioni</h2>
  <p class="sub text-sm mt-1 mb-4">Tocca le stelle e aggiungi un commento: una recensione per persona, riscrivendola si aggiorna.</p>
  <div class="grid lg:grid-cols-[1fr_330px] gap-5">
    <div class="card p-5">
      <ul>${(b.reviews || []).map(revRow).join('')
        || '<li class="sub text-sm py-2">Ancora nessuna recensione: sii il primo a dire cosa ne pensi.</li>'}</ul>
    </div>
    <div class="card p-5 grid gap-3 content-start self-start">
      <h3 class="font-bold">${mine ? 'Aggiorna la tua recensione' : 'Lascia una recensione'}</h3>
      <div class="flex gap-1.5">${[1, 2, 3, 4, 5].map(n =>
        `<button class="revstar ${n <= REV.stars ? 'on' : ''}" data-revstar="${n}" aria-label="${n} ${n === 1 ? 'stella' : 'stelle'}">★</button>`).join('')}</div>
      <form data-review="${b.id}" class="grid gap-3">
        <textarea name="comment" class="field" rows="3" maxlength="500" placeholder="Commento (facoltativo)">${esc(mine?.comment || '')}</textarea>
        <button class="btn" ${REV.stars ? '' : 'disabled'}>${mine ? 'Aggiorna recensione' : 'Pubblica recensione'}</button>
      </form>
    </div>
  </div>`;
}

/* ===================== STATISTICHE ===================== */
async function viewStats() {
  const s = await api('/stats');
  const kpi = (v, l, ico) => `<div class="card kpi p-5">
    <div class="flex items-center gap-2.5 mb-3">${ico ? `<div class="kico">${ICONS[ico]}</div>` : ''}<div class="sub text-[13px] font-medium leading-tight">${l}</div></div>
    <div style="font-size:36px;font-weight:700;letter-spacing:-.04em;line-height:1">${v}</div></div>`;
  /* Scala dei gradi: una riga per grado, dalla più facile alla più difficile.
     Barra segmentata verde (flash) + arancione (top), accanto i conteggi. */
  const ladder = (rows, max) => `<div class="ladder">` + rows.map(r => {
    const n = r.flash + r.top, tot = n + r.fail;
    const w = v => `${Math.max((v / max) * 100, 6)}%`;
    return `<div class="row">
      <div class="flex items-center gap-2">${GCOL[r.grade] ? `<span class="dot" style="background:${GCOL[r.grade]}"></span>` : ''}
        <span class="text-sm font-bold">${GCOL[r.grade] ? cap(r.grade) : r.grade}</span></div>
      <div class="bar">${r.flash ? `<i class="b-flash" style="width:${w(r.flash)}"></i>` : ''}${r.top ? `<i class="b-top" style="width:${w(r.top)}"></i>` : ''}</div>
      <div class="num">${tot ? `${plural(n, 'chiuso', 'chiusi')}${r.fail ? ` · ${r.fail} ✗` : ''}` : '<span class="sub" style="font-weight:500">ancora 0</span>'}</div>
    </div>`;
  }).join('') + `</div>`;
  const used = s.byGrade.filter(r => r.flash + r.top + r.fail > 0);
  const max = Math.max(1, ...s.byGrade.map(r => r.flash + r.top));
  const font = s.byGrade.filter(r => !GCOL[r.grade]), colors = s.byGrade.filter(r => GCOL[r.grade]);
  const block = (t, rows) => `<h2 class="text-2xl font-bold mt-8 mb-1" style="letter-spacing:-.025em">${t}</h2>
    <p class="sub text-sm mb-3">Dalla più facile alla più difficile · <span style="color:var(--green)">●</span> flash &nbsp;<span style="color:var(--orange)">●</span> top &nbsp;✗ tentativi</p>
    <div class="card p-4">${ladder(rows, max)}</div>`;

  $('#app').innerHTML = head('Statistiche', '', 'I tuoi progressi, sessione dopo sessione.') + `
  <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
    ${kpi(s.sessions, 'sessioni', 'board')}${kpi(s.sends, 'blocchi chiusi', 'flag')}${kpi(s.flashRate + '%', 'tasso di flash', 'bolt')}
    ${kpi(s.hardest ? (GCOL[s.hardest] ? cap(s.hardest) : s.hardest) : '–', 'grado massimo', 'trophy')}
  </div>
  ${used.length ? block('Scala dei colori della palestra', colors) + block('Scala Font', font)
    : empty('chart', 'Ancora nessun dato', 'Registra qualche blocco in una sessione per vedere la tua scala dei gradi.',
      '<a class="btn sm" href="#sessions" style="text-decoration:none">Vai alle sessioni</a>')}`;
}

/* ===================== PROFILO & DASHBOARD ADMIN ===================== */
async function viewProfilo() {
  const [sessions, boulders] = await Promise.all([api('/sessions'), api('/boulders')]);
  const mine = boulders.filter(b => b.mine);
  const logs = sessions.reduce((a, s) => a + s.logs.length, 0);
  const sent = sessions.reduce((a, s) => a + s.logs.filter(l => l.style !== 'fail').length, 0);
  const kpi = (v, l) => `<div class="card p-4"><div class="sub text-xs font-semibold uppercase tracking-[.12em]">${l}</div>
    <div style="font-size:30px;font-weight:700;letter-spacing:-.03em;margin-top:4px">${v}</div></div>`;
  const initials = ME.name.trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();

  let adminBlock = '';
  if (ME.admin) {
    const users = await api('/admin/users');
    adminBlock = `
    <h2 class="text-2xl font-bold mt-10 mb-1" style="letter-spacing:-.025em">Gestione account</h2>
    <p class="sub text-sm mb-3">Tutti gli account creati sulla palestra. Eliminandone uno spariscono le sue sessioni e le sue vie; le salite già registrate dagli altri restano.</p>
    <div class="card p-2 grid gap-1">
      ${users.map(u => `<div class="flex items-center gap-3 px-3 py-2.5 rounded-xl" style="background:var(--fill)">
        <div class="avatar" style="width:40px;height:40px;font-size:15px">${u.name.trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase()}</div>
        <div class="flex-1 min-w-0">
          <div class="font-semibold text-sm truncate">${esc(u.name)}${u.email.toLowerCase() === ME.email.toLowerCase() ? ' <span class="chip fail" style="font-size:10px;padding:2px 7px">tu · admin</span>' : ''}</div>
          <div class="sub text-xs truncate">${esc(u.email)} · iscritto il ${fmtDate(u.joined)}</div>
        </div>
        <div class="text-right sub text-xs whitespace-nowrap">${plural(u.boulders, 'via', 'vie')}<br>${plural(u.sessions, 'sessione', 'sessioni')}</div>
        ${u.email.toLowerCase() === ME.email.toLowerCase() ? '' : `<button class="icon" data-admin-del-user="${u.id}" data-name="${esc(u.name)}" aria-label="Elimina account">${TRASH}</button>`}
      </div>`).join('') || '<p class="sub text-sm p-3">Nessun account oltre al tuo.</p>'}
    </div>`;
  }

  $('#app').innerHTML = head('Profilo', '', ME.admin ? 'Il riepilogo dei tuoi dati e la gestione della palestra.' : 'Il riepilogo di tutto quello che hai inserito nel logbook.') + `
  <div class="card p-5 flex items-center gap-4 flex-wrap">
    <div class="avatar">${initials}</div>
    <div class="flex-1 min-w-0">
      <div class="flex items-center gap-2 flex-wrap"><h2 class="text-xl font-bold">${esc(ME.name)}</h2>
        ${ME.admin ? '<span class="chip fail">Admin</span>' : ''}</div>
      <p class="sub text-sm truncate">${esc(ME.email)}${ME.joined ? ` · iscritto il ${fmtDate(ME.joined)}` : ''}</p>
    </div>
    <button class="btn sec sm" data-logout>Esci</button>
  </div>
  <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
    ${kpi(sessions.length, 'sessioni')}
    ${kpi(mine.length, 'vie create')}
    ${kpi(logs, 'blocchi registrati')}
    ${kpi(sent, 'chiusi')}
  </div>
  ${mine.length ? `<h3 class="font-bold mt-6 mb-2">Le tue vie più recenti</h3>
  <div class="grid gap-2">${mine.slice(0, 5).map(b => `<a href="#boulder/${b.id}" class="card p-3 flex items-center gap-3" style="text-decoration:none;color:inherit">
      ${grade(b.grade)}<span class="flex-1 truncate text-sm font-medium">${esc(b.name)}</span>
      <span class="sub text-xs truncate">${esc(b.wall_name)}${b.attached === false ? ' · foto precedente' : ''}</span></a>`).join('')}</div>` : ''}
  ${adminBlock}`;
}

/* ===================== EVENTI & ROUTER ===================== */
document.addEventListener('click', async e => {
  try {
    if (e.target.closest('#stage')) return handleStageClick(e);
    const t = e.target, d = t.closest('button,label');
    if (t.id === 'undo') { T.holds.pop(); return drawMarkers(); }
    if (t.id === 'clear') { T.holds = []; return drawMarkers(); }
    if (t.id === 'save') return await saveBoulder();
    if (t.id === 'wallSave') { // carica la foto del settore (solo admin)
      if (!WALLPICK?.file) return toast('Scegli una foto');
      const fd = new FormData();
      fd.append('image', WALLPICK.file);
      fd.append('sector', WALLPICK.sector);
      const w = await api('/walls', { method: 'POST', body: fd });
      $('#dlg').close();
      if (WALLPICK.url) URL.revokeObjectURL(WALLPICK.url);
      T.wallId = w.id; T.mapOpen = false; T.mapSel = w.sector; T.holds = []; clearPhoto(); T.mode = 'wall';
      toast('Foto del settore caricata'); return viewTracer();
    }
    if (!d) return;
    if (d.hasAttribute('data-close')) return $('#dlg').close();
    if (d.id === 'userBtn') { location.hash = '#profilo'; return; } // il nome in alto apre il profilo
    if (d.id === 'vmapBtn') return mapFilterSheet(); // filtro settori con la cartina
    if (d.hasAttribute('data-vclear')) { // nel foglio cartina: togli il filtro settore
      VIE.sector = ''; $('#dlg').close();
      const btn = $('#vmapBtn span'); if (btn) btn.textContent = 'Tutti i settori';
      return renderVie();
    }
    if (d.dataset.revstar) { // selezione stelle nella recensione
      REV.stars = +d.dataset.revstar;
      document.querySelectorAll('[data-revstar]').forEach(b => b.classList.toggle('on', +b.dataset.revstar <= REV.stars));
      const pb = document.querySelector('[data-review] button'); if (pb) pb.disabled = !REV.stars;
      return;
    }
    if (d.hasAttribute('data-del-review')) {
      if (!confirm('Eliminare la tua recensione?')) return;
      await del('/reviews/' + d.dataset.delReview);
      toast('Recensione eliminata'); return viewBoulder(REV.bid);
    }
    if (d.dataset.authMode) return showAuth(d.dataset.authMode);
    if (d.dataset.mode) {
      T.mode = d.dataset.mode; T.holds = [];
      document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('on', b.dataset.mode === T.mode));
      return drawStage();
    }
    if (d.dataset.vstatus) {
      VIE.status = d.dataset.vstatus;
      document.querySelectorAll('[data-vstatus]').forEach(b => b.classList.toggle('on', b.dataset.vstatus === VIE.status));
      return renderVie();
    }
    if (d.dataset.vscope) {
      VIE.scope = d.dataset.vscope;
      document.querySelectorAll('[data-vscope]').forEach(b => b.classList.toggle('on', b.dataset.vscope === VIE.scope));
      return renderVie();
    }
    if (d.dataset.vorigin) {
      VIE.origin = d.dataset.vorigin;
      document.querySelectorAll('[data-vorigin]').forEach(b => b.classList.toggle('on', b.dataset.vorigin === VIE.origin));
      return renderVie();
    }
    if (d.dataset.adminDelUser) {
      const name = d.dataset.name;
      if (!confirm(`Eliminare l'account di ${name}? Le sue sessioni e le sue vie spariscono; le salite già registrate restano.`)) return;
      await del('/admin/users/' + d.dataset.adminDelUser);
      toast('Account eliminato'); return viewProfilo();
    }
    if (d.hasAttribute('data-reset-filters')) {
      Object.assign(VIE, { q: '', sector: '', grade: '', status: 'all', origin: 'all' });
      $('#vq').value = ''; $('#vgrade').value = '';
      const mb = $('#vmapBtn span'); if (mb) mb.textContent = 'Tutti i settori';
      document.querySelectorAll('[data-vstatus]').forEach(b => b.classList.toggle('on', b.dataset.vstatus === 'all'));
      document.querySelectorAll('[data-vorigin]').forEach(b => b.classList.toggle('on', b.dataset.vorigin === 'all'));
      return renderVie();
    }
    if (d.dataset.porigin) {
      PICKV.origin = d.dataset.porigin;
      document.querySelectorAll('[data-porigin]').forEach(b => b.classList.toggle('on', b.dataset.porigin === PICKV.origin));
      return renderPick();
    }
    if (d.dataset.pstatus) {
      PICKV.status = d.dataset.pstatus;
      document.querySelectorAll('[data-pstatus]').forEach(b => b.classList.toggle('on', b.dataset.pstatus === PICKV.status));
      return renderPick();
    }
    if (d.id === 'pvmapBtn') { // filtro settori con la cartina, dentro la pagina di scelta
      const counts = {};
      (PICKV.all || []).forEach(b => { if (b.sector) counts[b.sector] = (counts[b.sector] || 0) + 1; });
      return mapFilterSheet(PICKV, renderPick, 'pvmapBtn', 'pvclear', counts);
    }
    if (d.hasAttribute('data-pvclear')) { // nel foglio cartina della scelta: togli il filtro settore
      PICKV.sector = '';
      const btn = $('#pvmapBtn span'); if (btn) btn.textContent = 'Tutti i settori';
      return renderPick();
    }
    if (d.hasAttribute('data-preset')) {
      Object.assign(PICKV, { q: '', sector: '', grade: '', status: 'all', origin: 'all' });
      const q = $('#pvq'); if (q) q.value = '';
      const g = $('#pvgrade'); if (g) g.value = '';
      const mb = $('#pvmapBtn span'); if (mb) mb.textContent = 'Tutti i settori';
      document.querySelectorAll('[data-pstatus]').forEach(b => b.classList.toggle('on', b.dataset.pstatus === 'all'));
      document.querySelectorAll('[data-porigin]').forEach(b => b.classList.toggle('on', b.dataset.porigin === 'all'));
      return renderPick();
    }
    if (d.hasAttribute('data-logout')) {
      await send('/auth/logout', {});
      ME = null; T.wallId = null; T.holds = []; T.mapOpen = true; T.mapSel = null; clearPhoto(); T.mode = 'wall';
      Object.assign(VIE, { q: '', sector: '', grade: '', status: 'all', scope: 'attuali', origin: 'all' }); location.hash = ''; return showAuth();
    }
    if (d.hasAttribute('data-new-session')) return newSessionSheet(d.dataset.afterBid ? +d.dataset.afterBid : null);
    if (d.dataset.freeblock) return freeBlockSheet(+d.dataset.freeblock);
    if (d.dataset.pickboulder) { location.hash = '#pick/' + d.dataset.pickboulder; return; } // pagina piena di scelta (come «Vie create»)
    if (d.dataset.pick && PICKV.sessionId) return logBoulderSheet(PICKV.sessionId, +d.dataset.pick);
    if (d.dataset.addSession) return addSessionSheet(+d.dataset.addSession);
    if (d.dataset.sessionPick) return logBoulderSheet(+d.dataset.sessionPick, +d.dataset.bid);
    if (d.hasAttribute('data-map-toggle')) { T.mapOpen = !T.mapOpen; if (!T.mapOpen) T.mapSel = T.wall?.sector ?? null; return viewTracer(); }
    if (d.dataset.rewall) return newWallSheet(+d.dataset.rewall);
    if (d.dataset.tool) {
      T.tool = d.dataset.tool;
      return document.querySelectorAll('[data-tool]').forEach(b => b.classList.toggle('on', b.dataset.tool === T.tool));
    }
    if (d.dataset.delWall) {
      const n = Number(d.dataset.nBoulders);
      if (!confirm(`Eliminare la foto di "${T.wall?.name}"? Le ${n || 0} vie tracciate su questa foto vengono archiviate e restano solo in «Vie create» (filtro «Tutte»).`)) return;
      await del('/walls/' + d.dataset.delWall);
      T.wallId = null; T.holds = []; T.mapOpen = true; T.mapSel = null; toast('Foto eliminata'); return viewTracer();
    }
    if (!(d.dataset.delSession || d.dataset.delLog || d.dataset.delBoulder)) return;
    if (!confirm('Eliminare definitivamente?')) return;
    if (d.dataset.delSession) { await del('/sessions/' + d.dataset.delSession); viewSessions(); }
    if (d.dataset.delLog) { await del('/logs/' + d.dataset.delLog); viewSessions(); }
    if (d.dataset.delBoulder) { await del('/boulders/' + d.dataset.delBoulder); location.hash = '#' + PREV; }
  } catch (err) { toast(err.message); }
});

document.addEventListener('submit', async e => {
  e.preventDefault();
  const f = e.target, el = f.elements;
  try {
    if (f.matches('[data-auth]')) {
      const reg = f.dataset.auth === 'register', err = $('#authErr'), b = f.querySelector('.btn');
      const fail = m => { err.textContent = m; err.hidden = false; };
      err.hidden = true;
      if (reg && el.password.value.length < 8) return fail('La password deve avere almeno 8 caratteri.');
      b.disabled = true;
      try {
        const r = await send(reg ? '/auth/register' : '/auth/login', { name: reg ? el.name.value : undefined, email: el.email.value, password: el.password.value });
        ME = r.user; return enter();
      } catch (x) {
        return fail(x instanceof TypeError ? 'Impossibile contattare il server. Controlla che Docker sia avviato.' : x.message);
      } finally { b.disabled = false; }
    }
    if (f.matches('[data-session]')) {
      const r = await send('/sessions', { date: el.date.value, gym: el.gym.value, notes: el.notes.value });
      $('#dlg').close(); toast('Sessione creata');
      if (f.dataset.afterBid) return logBoulderSheet(r.id, +f.dataset.afterBid); // creata dal dettaglio via: subito il log
      return viewSessions();
    }
    if (f.matches('[data-freeblock]')) {
      if (!el.grade.value) return toast('Scegli il grado');
      const flash = el.style.value === 'flash';
      await send(`/sessions/${f.dataset.freeblock}/logs`, {
        boulder_id: null, name: el.name.value, grade: el.grade.value,
        style: el.style.value, attempts: flash ? 1 : +el.attempts.value,
      });
      $('#dlg').close(); toast('Blocco aggiunto'); viewSessions();
    }
    if (f.matches('[data-review]')) { // pubblica/aggiorna la tua recensione del blocco
      if (!REV.stars) return toast('Tocca le stelle prima di pubblicare');
      await send(`/boulders/${f.dataset.review}/reviews`, { stars: REV.stars, comment: el.comment.value });
      toast('Recensione salvata'); return viewBoulder(f.dataset.review);
    }
    if (f.matches('[data-logboulder]')) {
      if (!el.grade.value) return toast('Scegli il grado');
      const flash = el.style.value === 'flash';
      await send(`/sessions/${f.dataset.logboulder}/logs`, {
        boulder_id: +f.dataset.bid, grade: el.grade.value,
        style: el.style.value, attempts: flash ? 1 : +el.attempts.value,
      });
      $('#dlg').close(); toast('Aggiunta alla sessione');
      if (location.hash.startsWith('#pick/')) location.hash = '#sessions'; else route(); // dalla pagina di scelta torni alla lista sessioni
    }
  } catch (err) { toast(err.message); }
});

document.addEventListener('change', async e => {
  const t = e.target, f = t.form;
  if (t.id === 'bOfficial') {
    const c = $('#bHoldColor'); if (c) c.hidden = !t.checked;
    const n = $('#bName'); // vie official: niente nome scelto — sarà il colore delle prese
    n.disabled = t.checked;
    n.placeholder = t.checked ? 'Nome automatico: il colore delle prese' : 'Nome del blocco';
    if (t.checked) n.value = '';
    $('#bGrade').innerHTML = gradeOpts('', t.checked); // official = solo colori palestra, niente scala Font
    return;
  }
  if (t.matches('input.ownPhoto') && t.files[0]) {
    try { T.photo = await shrink(t.files[0]); } catch (err) { return toast(err.message); }
    if (T.photoUrl) URL.revokeObjectURL(T.photoUrl);
    T.photoUrl = URL.createObjectURL(T.photo); T.holds = []; return drawStage();
  }
  if (t.matches('input.wallPhoto') && t.files[0]) {
    try { WALLPICK.file = await shrink(t.files[0]); } catch (err) { return toast(err.message); }
    if (WALLPICK.url) URL.revokeObjectURL(WALLPICK.url);
    WALLPICK.url = URL.createObjectURL(WALLPICK.file);
    const p = $('#wallPrev'); if (p) { p.hidden = false; p.innerHTML = `<img src="${WALLPICK.url}" class="max-h-44 rounded-xl" alt="Anteprima foto">`; }
    const s = $('#wallSave'); if (s) s.disabled = false;
    return;
  }
  if (t.name === 'style') {                 // flash = sempre 1 tentativo
    f.elements.attempts.disabled = t.value === 'flash';
    if (t.value === 'flash') f.elements.attempts.value = 1;
  }
  if (t.id === 'vgrade') { VIE.grade = t.value; renderVie(); }
  if (t.id === 'pvgrade') { PICKV.grade = t.value; renderPick(); }
});

document.addEventListener('input', e => {
  if (e.target.id === 'vq') { VIE.q = e.target.value; renderVie(); }
  if (e.target.id === 'pvq') { PICKV.q = e.target.value; renderPick(); }
  if (e.target.id === 'pkq' && PICK) { PICK.q = e.target.value; const l = $('#pkList'); if (l) l.innerHTML = pickListHTML(); }
});

const routes = { sessions: viewSessions, tracer: viewTracer, vie: viewVie, stats: viewStats, profilo: viewProfilo, boulder: viewBoulder, pick: viewPick };
async function route() {
  const [name, arg] = (location.hash.slice(1) || 'sessions').split('/');
  const r = routes[name] ? name : 'sessions';
  if (r !== 'boulder' && r !== 'pick') PREV = r;
  const tab = PREV;
  document.querySelectorAll('[data-r]').forEach(a => a.classList.toggle('active', a.dataset.r === tab));
  try { await routes[r](arg); } catch (err) { toast(err.message); }
}
window.addEventListener('hashchange', () => { window.scrollTo(0, 0); route(); });
/* ===================== LOGIN / LOGOUT ===================== */
function showAuth(mode = 'login') {
  const reg = mode === 'register' && META.registration;
  document.body.classList.add('out');
  $('#app').innerHTML = `
  <div class="max-w-sm mx-auto mt-8 md:mt-12">
    <div class="text-center mb-7">
      <picture>
        <source media="(prefers-color-scheme: dark)" srcset="/logo-light.svg">
        <img src="/logo.svg" alt="Climbo · Indoor Climbing" class="h-20 sm:h-24 w-auto mx-auto">
      </picture>
      <h1 class="title mt-6">Logbook</h1>
      <p class="sub mt-1.5">${reg ? 'Crea il tuo logbook boulder' : 'Accedi al tuo logbook boulder'}</p>
    </div>
    ${META.registration ? `<div class="seg mb-3"><button data-auth-mode="login" class="${reg ? '' : 'on'}">Accedi</button><button data-auth-mode="register" class="${reg ? 'on' : ''}">Registrati</button></div>` : ''}
    <form data-auth="${reg ? 'register' : 'login'}" class="card p-6 grid gap-3">
      ${reg ? '<input name="name" class="field" placeholder="Nome" required maxlength="60" autocomplete="name">' : ''}
      <input name="email" type="email" class="field" placeholder="Email" required autocomplete="email">
      <input name="password" type="password" class="field" placeholder="Password${reg ? ' (almeno 8 caratteri)' : ''}" required autocomplete="${reg ? 'new-password' : 'current-password'}">
      <p id="authErr" role="alert" class="text-sm text-center" style="color:var(--red)" hidden></p>
      <button class="btn mt-1">${reg ? 'Crea account' : 'Accedi'}</button>
    </form>
    <p class="sub text-xs text-center mt-7">Climbo Pisa · Indoor Climbing — <a class="link" href="https://climbopisa.it" target="_blank" rel="noopener">climbopisa.it</a></p>
  </div>`;
}

function enter() {
  document.body.classList.remove('out');
  $('#userbox').hidden = false; $('#uname').textContent = ME.name;
  $('#adminBadge').hidden = !ME.admin;
  return route();
}

(async () => {
  try {
    META = await api('/meta');
    ME = (await api('/auth/me')).user;
    await enter();
  } catch { if (!ME) showAuth(); }
})();
