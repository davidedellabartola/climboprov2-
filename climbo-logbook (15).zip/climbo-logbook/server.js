const express = require('express');
const multer = require('multer');
const { Pool } = require('pg');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const UPLOAD_DIR = process.env.UPLOAD_DIR || '/data/uploads';
const MAX_MB = Number(process.env.MAX_UPLOAD_MB || 10);
const ALLOW_REG = (process.env.ALLOW_REGISTRATION ?? 'true') !== 'false';
const SECURE_COOKIE = process.env.COOKIE_SECURE === 'true';
const SESSION_DAYS = 30;
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'davide@gmail.com').toLowerCase(); // l'account admin
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const pool = new Pool(); // legge PGHOST, PGUSER, PGPASSWORD, PGDATABASE dall'ambiente

const COLORS = ['bianco', 'verde', 'blu', 'giallo', 'arancione', 'rosso', 'viola'];
const FONT = ['4', '5', '5+', '6a', '6a+', '6b', '6b+', '6c', '6c+', '7a', '7a+', '7b', '7b+', '7c', '7c+', '8a'];
const GRADES = [...COLORS, ...FONT];
const GYM_GRADES = COLORS; // le vie "Climbo Official" (già montate dai setters) si votano solo coi colori della palestra
const STYLES = ['flash', 'top', 'fail'];
const HOLD_TYPES = ['start', 'mid', 'top'];

/* Settori della palestra: geometria fissata, nomi univoci per numero. La foto di ogni settore
   viene caricata dall'admin (una riga walls per settore); sector NULL non esiste più. */
const SECTORS = [
  { id: 1, name: 'Appoggiato' },
  { id: 2, name: 'Placca' },
  { id: 3, name: 'Tetto' },
  { id: 4, name: 'Placca' },
  { id: 5, name: 'Placca lievemente strapiombante' },
  { id: 6, name: 'Strapiombetto obliquo' },
  { id: 7, name: 'Strapiombo' },
  { id: 8, name: 'Strapiombetto obliquo' },
  { id: 9, name: 'Placca lievemente strapiombante' },
  { id: 10, name: 'Placca' },
];

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS auth_sessions (
  token_hash TEXT PRIMARY KEY, user_id INT NOT NULL REFERENCES users ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL);
CREATE TABLE IF NOT EXISTS walls (
  id SERIAL PRIMARY KEY, name TEXT NOT NULL, image_url TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS boulders (
  id SERIAL PRIMARY KEY, wall_id INT NOT NULL REFERENCES walls ON DELETE CASCADE,
  name TEXT NOT NULL, grade TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS holds (
  id SERIAL PRIMARY KEY, boulder_id INT NOT NULL REFERENCES boulders ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('start','mid','top')),
  x DOUBLE PRECISION NOT NULL CHECK (x BETWEEN 0 AND 100),
  y DOUBLE PRECISION NOT NULL CHECK (y BETWEEN 0 AND 100),
  seq INT NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions (
  id SERIAL PRIMARY KEY, date DATE NOT NULL, gym TEXT NOT NULL DEFAULT 'Climbo Pisa',
  notes TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS logs (
  id SERIAL PRIMARY KEY, session_id INT NOT NULL REFERENCES sessions ON DELETE CASCADE,
  boulder_id INT REFERENCES boulders ON DELETE SET NULL,
  name TEXT NOT NULL DEFAULT '', grade TEXT NOT NULL,
  style TEXT NOT NULL CHECK (style IN ('flash','top','fail')),
  attempts INT NOT NULL DEFAULT 1 CHECK (attempts >= 1),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
-- multi-utente (migrazione sicura per database creati prima del login)
ALTER TABLE walls    ADD COLUMN IF NOT EXISTS user_id INT REFERENCES users ON DELETE CASCADE;
ALTER TABLE walls    ADD COLUMN IF NOT EXISTS sector INT; -- settore della cartina (1-10)
ALTER TABLE boulders ADD COLUMN IF NOT EXISTS user_id INT REFERENCES users ON DELETE CASCADE;
ALTER TABLE boulders ADD COLUMN IF NOT EXISTS image_url TEXT; -- foto dedicata alla singola via (facoltativa)
ALTER TABLE boulders ADD COLUMN IF NOT EXISTS wall_label TEXT; -- nome della parete al momento della creazione (resta anche se la parete viene archiviata)
ALTER TABLE boulders ADD COLUMN IF NOT EXISTS official BOOLEAN NOT NULL DEFAULT false; -- badge "Climbo Official": via già montata in palestra dai setters, aggiunta al logbook da un utente
ALTER TABLE boulders ADD COLUMN IF NOT EXISTS hold_color TEXT; -- colore delle prese (testo libero, per le vie official)
ALTER TABLE boulders ALTER COLUMN wall_id DROP NOT NULL; -- vie archiviate: wall_id NULL, restano solo in "Vie create"
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS user_id INT REFERENCES users ON DELETE CASCADE;
CREATE UNIQUE INDEX IF NOT EXISTS idx_walls_user_sector ON walls(user_id, sector) WHERE sector IS NOT NULL;
CREATE TABLE IF NOT EXISTS reviews (
  id SERIAL PRIMARY KEY,
  boulder_id INT NOT NULL REFERENCES boulders(id) ON DELETE CASCADE,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  stars INT NOT NULL CHECK (stars BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (boulder_id, user_id) -- una recensione per utente: riscrivendo si aggiorna
);
CREATE INDEX IF NOT EXISTS idx_reviews_boulder ON reviews(boulder_id);
CREATE INDEX IF NOT EXISTS idx_logs_session ON logs(session_id);
CREATE INDEX IF NOT EXISTS idx_holds_boulder ON holds(boulder_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_boulders_user ON boulders(user_id);
`;

async function initDb() {
  for (let i = 1; i <= 20; i++) {
    try {
      await pool.query(SCHEMA);
      await pool.query('DELETE FROM auth_sessions WHERE expires_at < now()');
      // pulizia una tantum: le pareti fuori cartina non esistono più (es. "Parete demo");
      // le vie attaccate a quelle pareti vengono eliminate a cascata, le salite restano nei log
      const old = await pool.query(`SELECT w.image_url AS wall_img, array_remove(array_agg(b.image_url), NULL) AS b_imgs
        FROM walls w LEFT JOIN boulders b ON b.wall_id = w.id WHERE w.sector IS NULL GROUP BY w.id`);
      const rm = [];
      old.rows.forEach(r => { rm.push(r.wall_img, ...r.b_imgs); });
      for (const url of rm) await rmFile(url);
      if (old.rowCount) await pool.query('DELETE FROM walls WHERE sector IS NULL');
      return;
    } catch (e) {
      console.log(`DB non pronto (${i}/20): ${e.message}`);
      await new Promise(r => setTimeout(r, 2000));
    }
  }
  throw new Error('Database non raggiungibile');
}

const bad = (msg, status = 400) => Object.assign(new Error(msg), { status });
const wrap = fn => (req, res, next) => fn(req, res, next).catch(next);
const str = (v, max) => String(v ?? '').trim().slice(0, max);
const rmFile = async url => {
  if (url && url.startsWith('/uploads/')) await fs.promises.unlink(path.join(UPLOAD_DIR, path.basename(url))).catch(() => {});
};

/* ---------- Autenticazione: password scrypt + cookie di sessione httpOnly ---------- */
const sha = t => crypto.createHash('sha256').update(t).digest('hex');
const scrypt = (pw, salt) => new Promise((ok, ko) => crypto.scrypt(pw, salt, 64, (e, k) => (e ? ko(e) : ok(k))));
const hashPw = async pw => { const salt = crypto.randomBytes(16); return salt.toString('hex') + ':' + (await scrypt(pw, salt)).toString('hex'); };
const checkPw = async (pw, stored) => {
  const [s, h] = stored.split(':'); const k = await scrypt(pw, Buffer.from(s, 'hex')); const hb = Buffer.from(h, 'hex');
  return hb.length === k.length && crypto.timingSafeEqual(hb, k);
};
const parseCookies = h => Object.fromEntries((h || '').split(';').map(c => c.trim().split('=')).filter(p => p[0])
  .map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
const setCookie = (res, token, maxAge) => res.setHeader('Set-Cookie',
  `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${SECURE_COOKIE ? '; Secure' : ''}`);

async function startSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  await pool.query(`INSERT INTO auth_sessions(token_hash, user_id, expires_at) VALUES ($1, $2, now() + interval '${SESSION_DAYS} days')`, [sha(token), userId]);
  setCookie(res, token, SESSION_DAYS * 86400);
}

const requireAuth = wrap(async (req, res, next) => {
  const t = parseCookies(req.headers.cookie).sid;
  if (t) {
    const { rows } = await pool.query(
      'SELECT u.id, u.name, u.email, u.created_at FROM auth_sessions a JOIN users u ON u.id = a.user_id WHERE a.token_hash = $1 AND a.expires_at > now()', [sha(t)]);
    if (rows[0]) { req.user = rows[0]; return next(); }
  }
  res.status(401).json({ error: 'Accedi per continuare' });
});

// payload utente verso il client: admin = account con email ADMIN_EMAIL
const pubUser = u => ({
  id: u.id, name: u.name, email: u.email,
  admin: (u.email || '').toLowerCase() === ADMIN_EMAIL,
  joined: u.created_at ? u.created_at.toISOString().slice(0, 10) : null,
});
const requireAdmin = (req, res, next) =>
  (req.user.email || '').toLowerCase() === ADMIN_EMAIL ? next() : res.status(403).json({ error: 'Riservato all\'admin' });

// limite tentativi di login: 10 errori / 15 minuti per IP+email
const attempts = new Map();
const recent = k => (attempts.get(k) || []).filter(t => Date.now() - t < 15 * 60 * 1000);
setInterval(() => attempts.clear(), 15 * 60 * 1000).unref();

const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => {
      const ext = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' }[file.mimetype];
      cb(null, crypto.randomUUID() + ext);
    },
  }),
  limits: { fileSize: MAX_MB * 1024 * 1024 },
  fileFilter: (req, file, cb) =>
    ['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype) ? cb(null, true) : cb(bad('Formato non valido: usa JPG, PNG o WebP')),
});

const app = express();
app.use(express.json({ limit: '1mb' }));
// no-cache: il browser riverifica (etag → 304) e applica subito le nuove versioni di app.js/index.html
app.use(express.static(path.join(__dirname, 'public'), { setHeaders: res => res.setHeader('Cache-Control', 'no-cache') }));

app.get('/api/meta', (req, res) => res.json({ font: FONT, colors: COLORS, styles: STYLES, registration: ALLOW_REG, sectors: SECTORS }));

app.post('/api/auth/register', wrap(async (req, res) => {
  if (!ALLOW_REG) throw bad('Le registrazioni sono chiuse', 403);
  const name = str(req.body.name, 60), email = str(req.body.email, 120).toLowerCase(), password = String(req.body.password ?? '');
  if (!name) throw bad('Inserisci il tuo nome');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw bad('Email non valida');
  if (password.length < 8 || password.length > 200) throw bad('La password deve avere almeno 8 caratteri');
  const first = (await pool.query('SELECT 1 FROM users LIMIT 1')).rowCount === 0;
  let user;
  try {
    user = (await pool.query('INSERT INTO users(email, name, password_hash) VALUES ($1,$2,$3) RETURNING id, name, email, created_at',
      [email, name, await hashPw(password)])).rows[0];
  } catch (e) { if (e.code === '23505') throw bad('Esiste già un account con questa email'); throw e; }
  if (first) { // il primo account eredita i dati creati prima dell'introduzione del login
    await pool.query("UPDATE walls SET user_id = $1 WHERE user_id IS NULL AND image_url LIKE '/uploads/%'", [user.id]);
    await pool.query('UPDATE boulders SET user_id = $1 WHERE user_id IS NULL', [user.id]);
    await pool.query('UPDATE sessions SET user_id = $1 WHERE user_id IS NULL', [user.id]);
  }
  await startSession(res, user.id);
  res.status(201).json({ user: pubUser(user) });
}));

app.post('/api/auth/login', wrap(async (req, res) => {
  const email = str(req.body.email, 120).toLowerCase(), password = String(req.body.password ?? '');
  const key = req.ip + '|' + email;
  if (recent(key).length >= 10) throw bad('Troppi tentativi. Riprova tra qualche minuto', 429);
  const u = (await pool.query('SELECT * FROM users WHERE email = $1', [email])).rows[0];
  if (!u || !(await checkPw(password, u.password_hash))) {
    attempts.set(key, [...recent(key), Date.now()]);
    throw bad('Email o password non corretti', 401);
  }
  attempts.delete(key);
  await startSession(res, u.id);
  res.json({ user: pubUser(u) });
}));

app.post('/api/auth/logout', wrap(async (req, res) => {
  const t = parseCookies(req.headers.cookie).sid;
  if (t) await pool.query('DELETE FROM auth_sessions WHERE token_hash = $1', [sha(t)]);
  setCookie(res, '', 0);
  res.status(204).end();
}));

app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: pubUser(req.user) }));

// Da qui in poi tutto richiede il login (foto comprese)
app.use('/uploads', requireAuth, express.static(UPLOAD_DIR, { maxAge: '7d', immutable: true }));
app.use('/api', requireAuth);

// ---------- Pareti (foto dei settori, solo admin) ----------
app.get('/api/walls', wrap(async (req, res) => {
  res.json((await pool.query('SELECT id, name, image_url, sector FROM walls ORDER BY id')).rows);
}));

const archiveBoulders = async wallId => { // il cambio foto "svuota" la parete: le vie restano solo in "Vie create"
  await pool.query(`UPDATE boulders SET wall_id = NULL, image_url = COALESCE(image_url, $2)
    WHERE wall_id = $1 AND image_url IS NULL`, [wallId, (await pool.query('SELECT image_url FROM walls WHERE id = $1', [wallId])).rows[0]?.image_url]);
  await pool.query('UPDATE boulders SET wall_id = NULL WHERE wall_id = $1', [wallId]);
};

app.post('/api/walls', requireAdmin, upload.single('image'), wrap(async (req, res) => {
  if (!req.file) throw bad('Nessuna immagine ricevuta');
  const url = '/uploads/' + req.file.filename;
  const sector = Number(req.body.sector);
  if (!SECTORS.some(s => s.id === sector)) throw bad('Settore non valido');
  const name = SECTORS.find(s => s.id === sector).name;
  try {
    const ex = await pool.query('SELECT id, image_url FROM walls WHERE sector = $1', [sector]);
    if (ex.rowCount) { // sostituzione foto: le vie già tracciate vengono archiviate, non eliminate
      await archiveBoulders(ex.rows[0].id);
      await rmFile(ex.rows[0].image_url);
      const { rows } = await pool.query('UPDATE walls SET image_url = $1, user_id = $2, name = $3 WHERE id = $4 RETURNING id, name, image_url, sector',
        [url, req.user.id, name, ex.rows[0].id]);
      return res.status(201).json(rows[0]);
    }
    const { rows } = await pool.query(
      'INSERT INTO walls(name, image_url, user_id, sector) VALUES ($1, $2, $3, $4) RETURNING id, name, image_url, sector',
      [name, url, req.user.id, sector]);
    res.status(201).json(rows[0]);
  } catch (e) { await rmFile(url); throw e; } // niente foto orfane se qualcosa va storto
}));

app.delete('/api/walls/:id', requireAdmin, wrap(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) throw bad('Parete non valida');
  const { rows } = await pool.query('SELECT image_url FROM walls WHERE id = $1', [id]);
  if (!rows.length) throw bad('Parete non trovata', 404);
  await archiveBoulders(id); // le vie restano in "Vie create" con la loro foto
  await pool.query('DELETE FROM walls WHERE id = $1', [id]);
  await rmFile(rows[0].image_url); // la foto della parete; le foto delle vie archiviate restano
  res.status(204).end();
}));

// ---------- Dashboard admin: gestione account ----------
app.get('/api/admin/users', requireAdmin, wrap(async (req, res) => {
  res.json((await pool.query(`
    SELECT u.id, u.name, u.email, to_char(u.created_at, 'YYYY-MM-DD') AS joined,
      (SELECT count(*)::int FROM boulders b WHERE b.user_id = u.id) AS boulders,
      (SELECT count(*)::int FROM sessions s WHERE s.user_id = u.id) AS sessions,
      (SELECT count(*)::int FROM logs l JOIN sessions s2 ON s2.id = l.session_id WHERE s2.user_id = u.id) AS logs
    FROM users u ORDER BY u.id`)).rows);
}));

app.delete('/api/admin/users/:id', requireAdmin, wrap(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) throw bad('Account non valido');
  const u = (await pool.query('SELECT id, email FROM users WHERE id = $1', [id])).rows[0];
  if (!u) throw bad('Account non trovato', 404);
  if ((u.email || '').toLowerCase() === ADMIN_EMAIL) throw bad('L\'account admin non può essere eliminato', 403);
  // le vie attaccate alle sue pareti vengono archiviate, non perse
  const hisWalls = (await pool.query('SELECT id FROM walls WHERE user_id = $1', [id])).rows;
  for (const w of hisWalls) await archiveBoulders(w.id);
  await pool.query('DELETE FROM users WHERE id = $1', [id]); // a cascata: sue sessioni, log, vie, pareti
  res.status(204).end();
}));

// ---------- Blocchi personalizzati con prese (x,y in %) ----------
// Le vie sono visibili a tutta la palestra: author chi l'ha creata, mine se è tua, best = MIGLIORE salite TUA.
// attached = la parete ha ancora una foto valida; le vie archiviate (wall_id NULL, foto precedente
// salvata nell'oggetto) restano visibili solo in "Vie create" con il filtro "Tutte".
const boulderQuery = (id, uid) => pool.query(`
  SELECT b.id, b.wall_id, b.name, b.grade, COALESCE(b.image_url, w.image_url) AS image_url,
    (b.image_url IS NOT NULL) AS own_photo, COALESCE(w.name, b.wall_label, 'Foto precedente') AS wall_name,
    w.sector AS sector, (b.wall_id IS NOT NULL) AS attached,
    b.official, b.hold_color,
    (b.user_id = $2::int) AS mine, COALESCE(u.name, '—') AS author,
    COALESCE(json_agg(json_build_object('type', h.type, 'x', h.x, 'y', h.y) ORDER BY h.seq)
             FILTER (WHERE h.id IS NOT NULL), '[]') AS holds,
    (SELECT count(*)::int FROM logs l WHERE l.boulder_id = b.id) AS n_logs,
    (SELECT round(avg(r.stars)::numeric, 1) FROM reviews r WHERE r.boulder_id = b.id) AS rating,
    (SELECT CASE WHEN bool_or(l.style = 'flash') THEN 'flash' WHEN bool_or(l.style = 'top') THEN 'top'
                 WHEN count(*) > 0 THEN 'fail' END FROM logs l
             WHERE l.boulder_id = b.id AND l.session_id IN (SELECT id FROM sessions WHERE user_id = $2::int)) AS best
  FROM boulders b LEFT JOIN walls w ON w.id = b.wall_id LEFT JOIN users u ON u.id = b.user_id
  LEFT JOIN holds h ON h.boulder_id = b.id
  WHERE ($1::int IS NULL OR b.id = $1::int)
  GROUP BY b.id, w.id, u.id ORDER BY b.id DESC`, [id, uid]);

app.get('/api/boulders', wrap(async (req, res) => res.json((await boulderQuery(null, req.user.id)).rows)));

app.get('/api/boulders/:id', wrap(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) throw bad('Blocco non valido');
  const b = (await boulderQuery(id, req.user.id)).rows[0];
  if (!b) throw bad('Blocco non trovato', 404);
  b.logs = (await pool.query(`
    SELECT l.id, l.style, l.attempts, to_char(s.date, 'YYYY-MM-DD') AS date, s.gym, COALESCE(u.name, '—') AS user_name
    FROM logs l JOIN sessions s ON s.id = l.session_id LEFT JOIN users u ON u.id = s.user_id
    WHERE l.boulder_id = $1 ORDER BY s.date DESC, l.id DESC`, [id])).rows;
  b.reviews = (await pool.query(`
    SELECT r.id, r.stars, r.comment, r.user_id, to_char(r.updated_at, 'YYYY-MM-DD') AS date,
      COALESCE(u.name, '—') AS user_name
    FROM reviews r LEFT JOIN users u ON u.id = r.user_id
    WHERE r.boulder_id = $1 ORDER BY r.updated_at DESC`, [id])).rows;
  res.json(b);
}));

// ---------- Recensioni (stelle + commento, una per utente: riscrivendo si aggiorna) ----------
app.post('/api/boulders/:id/reviews', wrap(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) throw bad('Blocco non valido');
  if (!(await pool.query('SELECT 1 FROM boulders WHERE id = $1', [id])).rowCount) throw bad('Blocco non trovato', 404);
  const stars = parseInt(req.body.stars, 10);
  if (!(stars >= 1 && stars <= 5)) throw bad('Dai da 1 a 5 stelle');
  const comment = str(req.body.comment, 500);
  await pool.query(`INSERT INTO reviews(boulder_id, user_id, stars, comment) VALUES ($1,$2,$3,$4)
    ON CONFLICT (boulder_id, user_id) DO UPDATE SET stars = $3, comment = $4, updated_at = now()`,
    [id, req.user.id, stars, comment]);
  res.status(201).json({ ok: true });
}));

app.delete('/api/reviews/:id', wrap(async (req, res) => {
  const { rows } = await pool.query('DELETE FROM reviews WHERE id = $1 AND user_id = $2 RETURNING id',
    [req.params.id, req.user.id]);
  if (!rows.length) throw bad('Puoi eliminare solo la tua recensione', 404);
  res.status(204).end();
}));

app.post('/api/boulders', upload.single('image'), wrap(async (req, res) => {
  // multipart: campi di testo + holds (JSON) + foto opzionale della singola via
  const photo = req.file ? '/uploads/' + req.file.filename : null;
  try {
    let holds = req.body.holds;
    if (typeof holds === 'string') { try { holds = JSON.parse(holds); } catch { throw bad('Prese non valide'); } }
    const wall_id = Number(req.body.wall_id);
    // badge "Climbo Official" (via già montata in palestra): senza nome scelto dall'utente —
    // il nome è il colore delle prese (obbligatorio) e il grado è solo un colore della palestra
    const official = req.body.official === 'true' || req.body.official === true || req.body.official === '1';
    const hold_color = official ? (str(req.body.hold_color, 40) || null) : null;
    if (official && !hold_color) throw bad('Indica il colore delle prese: sarà il nome della via ufficiale');
    const name = official ? (hold_color[0].toUpperCase() + hold_color.slice(1)) : str(req.body.name, 80);
    const grade = str(req.body.grade, 12);
    if (!name) throw bad('Dai un nome al blocco');
    if (!grade) throw bad('Scegli il grado');
    if (!(official ? GYM_GRADES : GRADES).includes(grade)) throw bad(official ? 'Per le vie Climbo Official il grado è un colore della palestra' : 'Grado non valido');
    if (!Number.isInteger(wall_id)) throw bad('Parete inesistente');
    if (!Array.isArray(holds) || holds.length < 2 || holds.length > 60) throw bad('Posiziona almeno una presa di partenza e una di arrivo');
    for (const h of holds) {
      if (!HOLD_TYPES.includes(h.type) || !(h.x >= 0 && h.x <= 100) || !(h.y >= 0 && h.y <= 100)) throw bad('Presa non valida');
    }
    if (!holds.some(h => h.type === 'start') || !holds.some(h => h.type === 'top')) throw bad('Servono almeno una presa Start e una Top');

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const wall = await client.query('SELECT id, name FROM walls WHERE id = $1', [wall_id]); // pareti solo admin: aperte a tutti per tracciare
      if (!wall.rowCount) throw bad('Parete inesistente');
      const b = await client.query('INSERT INTO boulders(wall_id, name, grade, user_id, image_url, wall_label, official, hold_color) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id',
        [wall_id, name, grade, req.user.id, photo, wall.rows[0].name, official, hold_color]);
      for (const [i, h] of holds.entries()) {
        await client.query('INSERT INTO holds(boulder_id, type, x, y, seq) VALUES ($1,$2,$3,$4,$5)', [b.rows[0].id, h.type, h.x, h.y, i]);
      }
      await client.query('COMMIT');
      res.status(201).json({ id: b.rows[0].id });
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally {
      client.release();
    }
  } catch (e) { await rmFile(photo); throw e; } // niente foto orfane se qualcosa va storto
}));

app.delete('/api/boulders/:id', wrap(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) throw bad('Blocco non valido');
  const { rows } = await pool.query('DELETE FROM boulders WHERE id = $1 AND user_id = $2 RETURNING image_url', [id, req.user.id]);
  if (!rows.length) throw bad('Puoi eliminare solo le vie che hai creato tu', 404);
  await rmFile(rows[0].image_url); // elimina anche la foto dedicata alla via
  res.status(204).end();
}));

// ---------- Sessioni e log ----------
app.get('/api/sessions', wrap(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT s.id, to_char(s.date, 'YYYY-MM-DD') AS date, s.gym, s.notes,
      COALESCE((SELECT json_agg(l ORDER BY l.id) FROM logs l WHERE l.session_id = s.id), '[]') AS logs
    FROM sessions s WHERE s.user_id = $1 ORDER BY s.date DESC, s.id DESC`, [req.user.id]);
  res.json(rows);
}));

app.post('/api/sessions', wrap(async (req, res) => {
  const date = str(req.body.date, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw bad('Data non valida');
  const { rows } = await pool.query(
    'INSERT INTO sessions(date, gym, notes, user_id) VALUES ($1,$2,$3,$4) RETURNING id',
    [date, str(req.body.gym, 80) || 'Climbo Pisa', str(req.body.notes, 1000), req.user.id]);
  res.status(201).json(rows[0]);
}));

app.delete('/api/sessions/:id', wrap(async (req, res) => {
  await pool.query('DELETE FROM sessions WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
  res.status(204).end();
}));

app.post('/api/sessions/:id/logs', wrap(async (req, res) => {
  const grade = str(req.body.grade, 12), style = str(req.body.style, 5);
  if (!GRADES.includes(grade)) throw bad('Grado non valido');
  if (!STYLES.includes(style)) throw bad('Stile non valido');
  let attempts = Math.max(1, Math.min(999, parseInt(req.body.attempts, 10) || 1));
  if (style === 'flash') attempts = 1;
  const s = await pool.query('SELECT 1 FROM sessions WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
  if (!s.rowCount) throw bad('Sessione inesistente', 404);
  let name = str(req.body.name, 80), boulderId = null;
  if (req.body.boulder_id) {
    const b = await pool.query('SELECT id, name FROM boulders WHERE id = $1', [req.body.boulder_id]); // vie anche di altri utenti
    if (b.rowCount) { boulderId = b.rows[0].id; name = b.rows[0].name; }
  }
  const { rows } = await pool.query(
    'INSERT INTO logs(session_id, boulder_id, name, grade, style, attempts) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id',
    [req.params.id, boulderId, name, grade, style, attempts]);
  res.status(201).json(rows[0]);
}));

app.delete('/api/logs/:id', wrap(async (req, res) => {
  await pool.query('DELETE FROM logs WHERE id = $1 AND session_id IN (SELECT id FROM sessions WHERE user_id = $2)', [req.params.id, req.user.id]);
  res.status(204).end();
}));

// ---------- Statistiche ----------
app.get('/api/stats', wrap(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT l.grade, count(*) FILTER (WHERE l.style='flash')::int AS flash,
           count(*) FILTER (WHERE l.style='top')::int AS top,
           count(*) FILTER (WHERE l.style='fail')::int AS fail
    FROM logs l JOIN sessions s ON s.id = l.session_id WHERE s.user_id = $1 GROUP BY l.grade`, [req.user.id]);
  const byGrade = GRADES.map(g => rows.find(r => r.grade === g) || { grade: g, flash: 0, top: 0, fail: 0 });
  const sum = k => byGrade.reduce((a, r) => a + r[k], 0);
  const sessions = (await pool.query('SELECT count(*)::int AS n FROM sessions WHERE user_id = $1', [req.user.id])).rows[0].n;
  const flash = sum('flash'), top = sum('top'), fail = sum('fail');
  const tried = flash + top + fail;
  res.json({
    sessions, flash, top, fail, tried, sends: flash + top,
    flashRate: tried ? Math.round((flash / tried) * 100) : 0,
    hardest: [...byGrade].reverse().find(r => r.flash + r.top > 0)?.grade || null,
    byGrade,
  });
}));

app.use('/api', (req, res) => res.status(404).json({ error: 'Rotta non trovata' }));
app.use((err, req, res, next) => {
  const status = err.status || (err.code === 'LIMIT_FILE_SIZE' ? 400 : 500);
  if (status === 500) console.error(err);
  res.status(status).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `Immagine troppo grande (max ${MAX_MB} MB)` : status === 500 ? 'Errore interno' : err.message });
});

initDb().then(() => app.listen(3000, () => console.log('Climbo Logbook su :3000'))).catch(e => { console.error(e); process.exit(1); });
